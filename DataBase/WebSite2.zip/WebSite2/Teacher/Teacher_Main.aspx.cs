﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Teacher_Default : System.Web.UI.Page
{
    static int current = 0;
    static String code = null;
    static int SSN=0;
    static int AssNum = -1;

    protected void Page_Load(object sender, EventArgs e)
    {

        String n = Convert.ToString(Session["TeacherName"]);
        L1.Text = "Teacher Name: " + n;
        int x = (int)Session["TeacherID"];
        L2.Text = "Teacher ID: "+x;
        changeCol();

        int id = x;
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Teacher_coursescodes", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        D1.DataSource = d;
        D1.DataTextField = "course_code";
        D1.DataValueField = "course_code";
        D1.DataBind();

        SqlCommand cmd2 = new SqlCommand("Teacher_studentSSN", conn);
        cmd2.CommandType = CommandType.StoredProcedure;
        cmd2.Parameters.Add(new SqlParameter("@teacher_id", id));
        cmd2.ExecuteNonQuery();
        SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        DataTable d2 = new DataTable();
        da2.Fill(d2);
        D2.DataSource = d2;
        D2.DataTextField = "ssn";
        D2.DataValueField = "ssn";
        D2.DataBind();
        conn.Close();

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        changeCol();
        clear();
        B1.BackColor = System.Drawing.Color.DarkSeaGreen;
        int id = (int)(Session["TeacherID"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Teacher_CoursesName", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        fill_grid(da);
        conn.Close();
        info.Text = "My Courses";
        info.Visible = true;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        changeCol();
        clear();
        B2.BackColor = System.Drawing.Color.DarkSeaGreen;
        current = 2;
        D1.Visible = true;
        LCourse.Visible = true;
        Done.Visible = true;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        changeCol();
        clear();
        B3.BackColor = System.Drawing.Color.DarkSeaGreen;
        current = 3;
        D1.Visible = true;
        LCourse.Visible = true;
        Done.Visible = true;
        Number.Text = "Assignment Number";
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        changeCol();
        clear();
        B4.BackColor = System.Drawing.Color.DarkSeaGreen;
        current = 4;
        D1.Visible = true;
        LCourse.Visible = true;
        Done.Visible = true;
        D2.Visible = true;
        LStudent.Visible = true;
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        changeCol();
        clear();
        B5.BackColor = System.Drawing.Color.DarkSeaGreen;
        current = 5;
        D1.Visible = true;
        LCourse.Visible = true;
        Done.Visible = true;
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        changeCol();
        clear();
        B6.BackColor = System.Drawing.Color.DarkSeaGreen;
        int id = (int)(Session["TeacherID"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Teacher_studentsIDS", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@teacher_id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        fill_grid(da);
        conn.Close();
        info.Text = "My Students";
        info.Visible = true;
    }
    protected void Done_Click(object sender, EventArgs e)
    {
        code=D1.SelectedItem.Text;
        if (current == 2)
        {
            D1.Visible = false;
            LCourse.Visible = false;
            Done.Visible = false;
            L3.Text = "Course Code "+code;
            L3.Visible = true;
            L4.Visible = true;
            L5.Visible = true;
            L6.Visible = true;
            T1.Visible = true;
            T2.Visible = true;
            T3.Visible = true;
            Done1.Visible = true;
            info.Text = "Posting Assignments";
            info.Visible = true;
        }
        if (current == 3)
        {
            if (D1.Visible)
            {
                int id = (int)Session["TeacherID"];
                string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
                SqlConnection conn = new SqlConnection(connStr);
                conn.Open();
                SqlCommand cmd = new SqlCommand("Teacher_AssignmentNumber", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@code", code));
                cmd.Parameters.Add(new SqlParameter("@teacher_id", id));
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable d = new DataTable();
                da.Fill(d);
                TNumber.DataSource = d;
                TNumber.DataTextField = "number";
                TNumber.DataValueField = "number";
                TNumber.DataBind();
                Number.Visible = true;
                TNumber.Visible = true;
                D1.Visible = false;
                LCourse.Visible = false;
            }
            else
            {
                String t = TNumber.SelectedItem.Text;
                AssNum = Convert.ToInt32(t);
                updateGrade();
            }
        }
        if (current == 4)
        {
            String t = D2.SelectedItem.Text; 
            int x = -1;
            try
            {
                x = Convert.ToInt32(t);
            }
            catch
            (Exception)
            {
                return;
            }
            D1.Visible = false;
            LCourse.Visible = false;
            Done.Visible = false;
            D2.Visible=false;
            LStudent.Visible = false;
            L3.Text = "Course Code " + code;
            L3.Visible = true;
            L6.Visible = true;
            T3.Visible = true;
            Done1.Visible = true;
            SSN = x;
            info.Text = "Write report to Student with ID "+x;
            info.Visible = true;
        }
        if(current == 5)
        {
            updateAnswer();
        }

    }

    protected void Done1_Click(object sender, EventArgs e)
    {
        if (current == 2)
        {
            if ((!string.IsNullOrWhiteSpace(T1.Text)) && (!string.IsNullOrWhiteSpace(T2.Text)) && (!string.IsNullOrWhiteSpace(T3.Text)))
            {
                int num;
                try
                {
                    num= Convert.ToInt32(T1.Text);
                }
                catch(Exception)
                {
                    Warning.Text = "Please enter a number";
                    Warning.Visible = true;
                    return;

                }
                int id = (int)(Session["TeacherID"]);
                String cont = T3.Text;
                String data = T2.Text;
                DateTime PDate = DateTime.Today;
                DateTime DDate;
                try
                {
                    DDate = Convert.ToDateTime(data);
                }
                catch(Exception )
                {
                    Warning.Text = "Please enter the date correctly";
                    Warning.Visible = true;
                    return;

                }
                string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
                SqlConnection conn = new SqlConnection(connStr);
                conn.Open();
                SqlCommand cmd = new SqlCommand("Teacher_PostAssignments", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@teacher_id", id));
                cmd.Parameters.Add(new SqlParameter("@code", code));
                cmd.Parameters.Add(new SqlParameter("@assignment_number", num));
                cmd.Parameters.Add(new SqlParameter("@posting_date", PDate));
                cmd.Parameters.Add(new SqlParameter("@content", cont));
                cmd.Parameters.Add(new SqlParameter("@due_date", DDate));
                try
                {
                    cmd.ExecuteNonQuery();
                    Warning.Text="Assignment is posted ";
                    Warning.Visible = true;
                }
                catch
                {
                    Warning.Text = "You already posted an assignment with the same number";
                    Warning.Visible = true;
                }
                conn.Close();
            }
            else
            {
                Warning.Text = "Please fill all the blank spaces";
                Warning.Visible = true;
            }
        }
        if (current == 4)
        {
            if (!string.IsNullOrWhiteSpace(T3.Text))
            {
                int id = (int)(Session["TeacherID"]);
                String cont = T3.Text;
                DateTime PDate = DateTime.Today;
                string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
                SqlConnection conn = new SqlConnection(connStr);
                conn.Open();
                SqlCommand cmd = new SqlCommand("Teacher_reports", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@teacher_id", id));
                cmd.Parameters.Add(new SqlParameter("@student_id", SSN));
                cmd.Parameters.Add(new SqlParameter("@date", PDate));
                cmd.Parameters.Add(new SqlParameter("@comment", cont));
                try
                {
                    cmd.ExecuteNonQuery();
                    Warning.Text = "Report is posted";
                    Warning.Visible = true;
                }
                catch (Exception)
                {
                    Warning.Text = "You already wrote a report to that sudent today";
                    Warning.Visible = true;
                }
                conn.Close();

            }
            else
            {
                Warning.Text = "Please fill all the blank spaces";
                Warning.Visible = true;
            }
        }

    }
    protected void fill_grid(SqlDataAdapter da)
    {
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        GridView1.Visible = true;

    }
    protected void fill_grid2(SqlDataAdapter da)
    {
        DataTable d = new DataTable();
        da.Fill(d);
        GridView2.DataSource = d;
        GridView2.DataBind();
        GridView2.Visible = true;

    }
    protected void changeCol()
    {
        B1.BackColor = System.Drawing.Color.LightGreen;
        B2.BackColor = System.Drawing.Color.LightGreen;
        B3.BackColor = System.Drawing.Color.LightGreen;
        B4.BackColor = System.Drawing.Color.LightGreen;
        B5.BackColor = System.Drawing.Color.LightGreen;
        B6.BackColor = System.Drawing.Color.LightGreen;

    }
    protected void clear()
    {
        GridView1.Visible = false;
        GridView2.Visible = false;
        D1.Visible = false;
        D2.Visible = false;
        Done.Visible = false;
        L3.Visible = false;
        L4.Visible = false;
        L5.Visible = false;
        L6.Visible = false;
        L7.Visible = false;
        T1.Visible = false;
        T2.Visible = false;
        T3.Visible = false;
        T4.Visible = false;
        Done1.Visible = false;
        Number.Visible = false;
        TNumber.Visible = false;
        info.Visible = false;
        Warning.Visible = false;

        LCourse.Visible = false;
        LStudent.Visible = false;

        T1.Text = "";
        T2.Text = "";
        T3.Text = "";
        T4.Text = "";
    }


    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {


        int a = GridView2.SelectedIndex;
        String t = T4.Text;
        if (t.Equals(""))
            return;

        if (current == 3)
        {
            int x = -1;
            try
            {
                x = Convert.ToInt32(t);
            }
            catch
            (Exception)
            {
                Warning.Text = "Please enter a number";
                Warning.Visible = true;
                return;
            }

            foreach (GridViewRow row in GridView2.Rows)
            {
                if (row.RowIndex == a)
                {
                    int sid = Convert.ToInt32(row.Cells[1].Text);
                    int id = (int)(Session["TeacherID"]);
                    string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
                    SqlConnection conn = new SqlConnection(connStr);
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("Teacher_gradeAssignment", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@teacher_id", id));
                    cmd.Parameters.Add(new SqlParameter("@student_id", sid));
                    cmd.Parameters.Add(new SqlParameter("@course_code", code));
                    cmd.Parameters.Add(new SqlParameter("@assignment_number", AssNum));
                    cmd.Parameters.Add(new SqlParameter("@grade", x));
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    updateGrade();
                }
            }
        }
        if (current == 5)
        {
            foreach (GridViewRow row in GridView2.Rows)
            {
                if (row.RowIndex == a)
                {
                    int sid = Convert.ToInt32(row.Cells[1].Text);
                    int num= Convert.ToInt32(row.Cells[2].Text);
                    String q = row.Cells[3].Text;
                    int id = (int)(Session["TeacherID"]);
                    string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
                    SqlConnection conn = new SqlConnection(connStr);
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("Teacher_AnswerStudent", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@teacher_id", id));
                    cmd.Parameters.Add(new SqlParameter("@number", num));
                    cmd.Parameters.Add(new SqlParameter("@student_id", sid));
                    cmd.Parameters.Add(new SqlParameter("@course_code", code));
                    cmd.Parameters.Add(new SqlParameter("@answer", t));
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    updateAnswer();
                }
            }
        }

    }
    protected void updateGrade()
    {

        int id = (int)(Session["TeacherID"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Teacher_Assignments", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@teacher_id", id));
        cmd.Parameters.Add(new SqlParameter("@code", code));
        cmd.Parameters.Add(new SqlParameter("@assignment_number", AssNum));
        SqlParameter n = cmd.Parameters.Add("@information", SqlDbType.VarChar, 1200);
        n.Direction = ParameterDirection.Output;
        cmd.ExecuteNonQuery();
        String inform = Convert.ToString(n.Value);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        info.Text = inform;
        if (inform.Equals(""))
        {
            Warning.Text = "No Assignment was found with that number";
            Warning.Visible = true;
            conn.Close();
            return;
        }
        info.Visible = true;
        fill_grid2(da);
        conn.Close();
        D1.Visible = false;
        LCourse.Visible = false;
        Done.Visible = false;
        Number.Visible = false;
        TNumber.Visible = false;
        L7.Visible = true;
        L7.Text = "Enter Grade here..";
        T4.Visible = true;
        Warning.Visible = false;
  }
    protected void updateAnswer()
    {
        int id = (int)(Session["TeacherID"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("Teacher_studentQuestionsAnswers", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@course_code", code));
        cmd.Parameters.Add(new SqlParameter("@teacher_id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        //info.Text = inform;
        //info.Visible = true;
        fill_grid2(da);
        conn.Close();
        D1.Visible = false;
        LCourse.Visible = false;
        Done.Visible = false;
        L7.Visible = true;
        L7.Text = "Enter Answer here..";
        T4.Visible = true;
        info.Text = "Students Questions";
        info.Visible = true;
    }
}