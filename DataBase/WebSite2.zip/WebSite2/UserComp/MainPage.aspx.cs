﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MainPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GridView1.Visible = false;
    }

    protected void Admin_login()
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("Admin_Login", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string user = username.Text;
        string password = pass.Text;

        cmd.Parameters.Add(new SqlParameter("@username", user));
        cmd.Parameters.Add(new SqlParameter("@password", password));
        SqlParameter o = cmd.Parameters.Add("@out", SqlDbType.Int);
        o.Direction = ParameterDirection.Output;

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        int id = Convert.ToInt32(o.Value.ToString());
        if (id != 0)
        {

            Session["field1"] = id;
            Response.Redirect("../Admin/AdminMain.aspx");
        }
        else
        {
            warning.Text = "You entered a wrong username or password";
        }




    }

    protected void Teacher_login()
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("Teacher_login", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string user = username.Text;
        string password = pass.Text;

        cmd.Parameters.Add(new SqlParameter("@username", user));
        cmd.Parameters.Add(new SqlParameter("@password", password));
        SqlParameter o = cmd.Parameters.Add("@id", SqlDbType.Int);
        SqlParameter n = cmd.Parameters.Add("@name", SqlDbType.VarChar, 100);


        o.Direction = ParameterDirection.Output;
        n.Direction = ParameterDirection.Output;
        conn.Open();
        cmd.ExecuteNonQuery();

        int id = (int)o.Value;

        conn.Close();
        if (id != 0)
        {
            String name = Convert.ToString(n.Value);
            Session["TeacherID"] = id;
            Session["TeacherName"] = name;
            Response.Redirect("~/Teacher/Teacher_Main.aspx", true);
        }
        else
        {
            warning.Text = "You entered a wrong username or password";
        }


    }
    protected void Student_login()
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("StudentLogIn", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string user = username.Text;
        string password = pass.Text;

        SqlParameter o = cmd.Parameters.Add("@ssn", SqlDbType.Int);
        cmd.Parameters.Add(new SqlParameter("@username", user));
        cmd.Parameters.Add(new SqlParameter("@password", password));

        o.Direction = ParameterDirection.Output;
        conn.Open();
        cmd.ExecuteNonQuery();
        int ssn = Convert.ToInt32(o.Value.ToString());
        conn.Close();
        if (ssn != 0)
        {

            Session["student"] = ssn;
            Response.Redirect("../Student/StudentMain.aspx", true);
        }
        else
        {
            warning.Text = "You entered a wrong username or password";
        }


    }


    public void login_parent()
    {
        //Get the information of the connection to the database
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("log_in", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string usernamee = username.Text;
        string passs = pass.Text;



        cmd.Parameters.Add(new SqlParameter("@username", usernamee));
        cmd.Parameters.Add(new SqlParameter("@password", passs));



        SqlParameter count = cmd.Parameters.Add("@o", SqlDbType.Int);
        count.Direction = ParameterDirection.Output;

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        if ((count.Value.ToString()).Equals("1"))
        {
            Session["parentusername"] = usernamee;
            Response.Redirect("../pages/Parent.aspx", true);


        }
        else
        {
            warning.Text = "You entered a wrong username or password";
        }
    }




    protected void Button2_Click(object sender, EventArgs e)
    {

        if ((!string.IsNullOrWhiteSpace(username.Text)) && (!string.IsNullOrWhiteSpace(pass.Text)))
        {
            if ((DropDownList1.SelectedValue).Equals("Admin"))
            {
                Admin_login();
                warning.Text = " ";
                username.Text = "";
                pass.Text = "";
            }
            else if ((DropDownList1.SelectedValue).Equals("Parent"))
            {
                login_parent();
                warning.Text = " ";
                username.Text = "";
                pass.Text = "";
            }
            else if ((DropDownList1.SelectedValue).Equals("Teacher"))
            {
                Teacher_login();
                warning.Text = " ";
                username.Text = "";
                pass.Text = "";
            }
            else if ((DropDownList1.SelectedValue).Equals("Student"))
            {
                Student_login();
                warning.Text = " ";
                username.Text = "";
                pass.Text = "";
            }
        }
        else
        {
            warning.Text = "Please fill in the blanks!!";
        }
    }
    protected void search_school(string s_name, string s_address, string s_type)
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("search_school", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@school_name", s_name));
        cmd.Parameters.Add(new SqlParameter("@school_address", s_address));
        cmd.Parameters.Add(new SqlParameter("@school_type", s_type));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();
    }




    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(name.Text))
        {
            search_school(name.Text, "nullnull", "");
            GridView1.Visible = true;
            name.Text = "";
        }
    }

    protected void saddress_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(address.Text))
        {
            search_school("nullnull", address.Text, "");
            GridView1.Visible = true;
            address.Text = "";
        }
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        search_school("nullnull", "nullnull", (DropDownList2.SelectedValue));
        GridView1.Visible = true;
    }
}

