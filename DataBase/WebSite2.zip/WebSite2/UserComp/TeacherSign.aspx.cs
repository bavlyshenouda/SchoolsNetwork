﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserComp_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void signup()
    {
        
        //Get the information of the connection to the database
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("Teacher_Signup1", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string fname = f_name.Text;
        string mname = m_name.Text;
        string lname = l_name.Text;
        DateTime birth = DateTime.ParseExact("2000-01-23", "yyyy-mm-dd", null);
        try
        {
             birth = DateTime.ParseExact(birth_date.Text, "yyyy-mm-dd", null);
        }
        catch (Exception)
        {
            warning.Text = "Please enter the date in the correct format YYYY-MM-DD";
            return;
        }
        string addr = address.Text;
        string em = email.Text;
        char gend = cgender.SelectedValue[0];
        int exp = Convert.ToInt32(expi.Text);


        cmd.Parameters.Add(new SqlParameter("@first_name",fname));
        cmd.Parameters.Add(new SqlParameter("@middle_name", mname));
        cmd.Parameters.Add(new SqlParameter("@last_name", lname));
        cmd.Parameters.Add(new SqlParameter("@birth_date", birth));
        cmd.Parameters.Add(new SqlParameter("@adress", addr));
        cmd.Parameters.Add(new SqlParameter("@email", em));
        cmd.Parameters.Add(new SqlParameter("@gender", gend));
        cmd.Parameters.Add(new SqlParameter("@exp",exp));

        SqlParameter count = cmd.Parameters.Add("@o", SqlDbType.Int);
        count.Direction = ParameterDirection.Output;

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        if (count.Value.ToString().Equals("1"))
        {
          warning.Text = "You have been registered successfully";
            f_name.Text = "";
            m_name.Text = "";
            l_name.Text = "";
            address.Text = "";
            expi.Text = "";
            birth_date.Text = "";
            email.Text = "";
        }
        else
        {
            warning.Text = "You are already registered with this e-mail  ";
        }
    }






    protected void Button1_Click(object sender, EventArgs e)
    {
        if ((!string.IsNullOrWhiteSpace(f_name.Text)) && (!string.IsNullOrWhiteSpace(m_name.Text)) && (!string.IsNullOrWhiteSpace(l_name.Text)) && (!string.IsNullOrWhiteSpace(birth_date.Text)) && (!string.IsNullOrWhiteSpace(address.Text)) && (!string.IsNullOrWhiteSpace(email.Text)) && (!string.IsNullOrWhiteSpace(expi.Text)))
        {
            signup();
        }
        else
        {
            warning.Text = "Please fill in all the blanks";
        }
            
    }
}