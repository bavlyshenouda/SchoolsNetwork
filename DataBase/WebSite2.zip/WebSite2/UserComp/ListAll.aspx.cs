﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserComp_ListAll : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("list_all_schools", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

        
        if ((DropDownList1.SelectedValue).Equals("Reviews"))
        {
            Session["school_id"] = Convert.ToInt32(GridView1.SelectedRow.Cells[1].Text);
            Response.Redirect("../UserComp/Reviews.aspx", true);
        }
        else
        {
            Session["school_id"] = Convert.ToInt32(GridView1.SelectedRow.Cells[1].Text);
            Response.Redirect("../UserComp/Announcements.aspx", true);
        }
    }
}