﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserComp_ParentSign : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void signup()
    {

        //Get the information of the connection to the database
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("Sign_up", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string f_name = fname.Text;
        string l_name = lname.Text;
        string addr = address.Text;
        string em = email.Text;
        string home = home_No.Text;
        string user = username.Text;
        string passw = pass.Text;


        cmd.Parameters.Add(new SqlParameter("@first_name", f_name));
        cmd.Parameters.Add(new SqlParameter("@lastname", l_name));
        cmd.Parameters.Add(new SqlParameter("@emai", em));
        cmd.Parameters.Add(new SqlParameter("@addres", addr));
        cmd.Parameters.Add(new SqlParameter("@home_numbe", home));
        cmd.Parameters.Add(new SqlParameter("@usernam", user));
        cmd.Parameters.Add(new SqlParameter("@passwor", passw));


        SqlParameter count = cmd.Parameters.Add("@o", SqlDbType.Int);
        count.Direction = ParameterDirection.Output;

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        if (count.Value.ToString().Equals("1"))
        {

            warning.Text = "You have been registered successfully";
        }
        else
        {
            warning.Text = "This Username is already used ";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if ((!string.IsNullOrWhiteSpace(username.Text)) && (!string.IsNullOrWhiteSpace(email.Text)) && (!string.IsNullOrWhiteSpace(pass.Text)) && (!string.IsNullOrWhiteSpace(address.Text)) && (!string.IsNullOrWhiteSpace(fname.Text)) && (!string.IsNullOrWhiteSpace(lname.Text)) && (!string.IsNullOrWhiteSpace(home_No.Text)))
        {
            signup();
        }
        else
        {
            warning.Text = "Please fill all the Fields";
        }


    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Parent.aspx", true);
    }
    protected void mobileinn()
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("inmobile", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string user = (String)Session["parentusername"];
        string mobil = mobili.Text;


        cmd.Parameters.Add(new SqlParameter("@usernam", user));
        cmd.Parameters.Add(new SqlParameter("@mobilenumber", mobil));
        SqlParameter count = cmd.Parameters.Add("@o", SqlDbType.Int);
        count.Direction = ParameterDirection.Output;

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        if (count.Value.ToString().Equals("1"))
        {
            warning.Text = "Added";
        }
        else
        {
            warning.Text = " You have Entered this mobile number before ";
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        if ((!string.IsNullOrWhiteSpace(mobili.Text)))
        {
            mobileinn();
        }
        else
        {

        }

    }
}