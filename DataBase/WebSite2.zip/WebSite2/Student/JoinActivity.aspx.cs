﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LoadInventoryCategoryDropDownList();
    }
    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("StudentMain.aspx", true);
    }
    private void LoadInventoryCategoryDropDownList()
    {

        if (!Page.IsPostBack)
        {
            int ssn = Convert.ToInt32(Session["student"]);
            SqlCommand SQLSelectCommand;
            SqlDataReader dtrInventoryCategory;

            string SQLDBConnString = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection SQLDBConn = new SqlConnection(SQLDBConnString);

            SQLDBConn.Open();

            SQLSelectCommand = new SqlCommand("ViewActivities", SQLDBConn);
            SQLSelectCommand.CommandType = CommandType.StoredProcedure;
            SQLSelectCommand.Parameters.Add(new SqlParameter("@ssn", ssn));

            dtrInventoryCategory = SQLSelectCommand.ExecuteReader();

            DropDownList1.DataSource = dtrInventoryCategory;

            DropDownList1.DataValueField = "activity_description"; // Alias Name from Sproc
            DropDownList1.DataTextField = "activity_description";   // Alias name from sproc
            DropDownList1.DataBind();

            SQLDBConn.Close();
        }
    }
    protected void Join(object sender, EventArgs e)
    {

        int ssn = Convert.ToInt32(Session["student"]);
        String activity = DropDownList1.SelectedValue;
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlCommand cmd = new SqlCommand("Ask", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@ssn", ssn));
            cmd.Parameters.Add(new SqlParameter("@id", activity));
            cmd.ExecuteNonQuery();
            conn.Close();
            Label2.Text = "Done";
    }
}