﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_Default : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void update(object sender, EventArgs e)
    {
        //Get the information of the connection to the database
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("EnrolledUpdate", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string name = TextBox1.Text;
        DateTime birthday = DateTime.ParseExact(TextBox2.Text, "dd/MM/yyyy", null);
        char G= DropDownList1.SelectedValue[0];
        String pass= TextBox4.Text;
        int ssn = Convert.ToInt32(Session["student"]);
        Label7.Text = Session["student"].ToString();
        string username = "moh_ahmed";
        int grade = Convert.ToInt32(TextBox5.Text);
        int level = Convert.ToInt32(DropDownList2.SelectedValue);
        if (name != null & birthday != null & pass != null & grade != 0 & level != 0)
        {
            cmd.Parameters.Add(new SqlParameter("@ssn", ssn));
            cmd.Parameters.Add(new SqlParameter("@name", name));
            cmd.Parameters.Add(new SqlParameter("@birth_date", birthday.Date));
            cmd.Parameters.Add(new SqlParameter("@gender", G));
            cmd.Parameters.Add(new SqlParameter("@username", username));
            cmd.Parameters.Add(new SqlParameter("@student_password", pass));
            cmd.Parameters.Add(new SqlParameter("@grade", grade));
            cmd.Parameters.Add(new SqlParameter("@level_id", level));
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            Label7.Text = "Done";
        }
        else
            Label7.Text = " Please fill all the essential fields,if you already filled them all then username entered is not correct ";
    }

    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("StudentMain.aspx", true);
    }
}