﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LoadInventoryCategoryDropDownList();
    }
    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("StudentMain.aspx", true);
    }
    private void LoadInventoryCategoryDropDownList()
    {

        if (!Page.IsPostBack)
        {
            int ssn = Convert.ToInt32(Session["student"]);
            SqlCommand SQLSelectCommand;
            SqlDataReader dtrInventoryCategory;

            string SQLDBConnString = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection SQLDBConn = new SqlConnection(SQLDBConnString);

            SQLDBConn.Open();
            SQLSelectCommand = new SqlCommand("ViewClubs", SQLDBConn);
            SQLSelectCommand.CommandType = CommandType.StoredProcedure;
            SQLSelectCommand.Parameters.Add(new SqlParameter("@ssn", ssn));
            dtrInventoryCategory = SQLSelectCommand.ExecuteReader();

            DropDownList1.DataSource = dtrInventoryCategory;

            DropDownList1.DataValueField = "name"; // Alias Name from Sproc
            DropDownList1.DataTextField = "name";   // Alias name from sproc
            DropDownList1.DataBind();

            SQLDBConn.Close();
        }
    }
    protected void Join(object sender, EventArgs e)
    {
        int ssn = Convert.ToInt32(Session["student"]);
        string name = DropDownList1.SelectedValue;
        SqlCommand SQLSelectCommand;
        SqlDataReader dtrInventoryCategory;

        string SQLDBConnString = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection SQLDBConn = new SqlConnection(SQLDBConnString);

        SQLDBConn.Open();
        SqlCommand cmd = new SqlCommand("GetSchool", SQLDBConn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@ssn", ssn));
        SqlParameter o = cmd.Parameters.Add("@school_id", SqlDbType.Int);
        o.Direction = ParameterDirection.Output;
        cmd.ExecuteNonQuery();
        int id = Convert.ToInt32(o.Value.ToString());
        //
        SQLSelectCommand = new SqlCommand("JoinClub", SQLDBConn);
        SQLSelectCommand.CommandType = CommandType.StoredProcedure;
        SQLSelectCommand.Parameters.Add(new SqlParameter("@ssn", ssn));
        SQLSelectCommand.Parameters.Add(new SqlParameter("@school_id", id));
        SQLSelectCommand.Parameters.Add(new SqlParameter("@club_name", name));
        try
        {
            dtrInventoryCategory = SQLSelectCommand.ExecuteReader();
            Label1.Text = "Done";
        }
        catch(Exception) { Label1.Text = "You are already registered in this club"; }
        SQLDBConn.Close();
       
    }
}