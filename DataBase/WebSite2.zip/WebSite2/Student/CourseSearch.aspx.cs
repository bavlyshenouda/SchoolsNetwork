﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Search(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        SqlConnection conn = new SqlConnection(connStr);
        
        SqlCommand cmd = new SqlCommand("CourseSearch", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string code = TextBox1.Text;
        string name = TextBox2.Text;
        if (!code.Equals(null) || !name.Equals(null))
        {
            cmd.Parameters.Add(new SqlParameter("@Course_Code ", code));
            cmd.Parameters.Add(new SqlParameter("@Course_Name ", name));
            conn.Open();
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable d = new DataTable();
            da.Fill(d);
            GridView1.DataSource = d;
            GridView1.DataBind();
            conn.Close();
            Label4.Text = "Results";


        }
        else 
            Label4.Text = "no courses found, make sure you enter a valid search";
    }

    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("StudentMain.aspx", true);
    }
}