﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_Default : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        LoadInventoryCategoryDropDownList();
    }
    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("StudentMain.aspx", true);
    }
    private void LoadInventoryCategoryDropDownList()
    {
        if (!Page.IsPostBack)
        {
            int ssn = Convert.ToInt32(Session["student"]);
            SqlCommand SQLSelectCommand;
            SqlDataReader dtrInventoryCategory;

            string SQLDBConnString = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection SQLDBConn = new SqlConnection(SQLDBConnString);

            SQLDBConn.Open();

            SQLSelectCommand = new SqlCommand("ViewCourses", SQLDBConn);
            SQLSelectCommand.CommandType = CommandType.StoredProcedure;
            SQLSelectCommand.Parameters.Add(new SqlParameter("@ssn", ssn));

            dtrInventoryCategory = SQLSelectCommand.ExecuteReader();

            DropDownList1.DataSource = dtrInventoryCategory;

            DropDownList1.DataValueField = "code"; // Alias Name from Sproc
            DropDownList1.DataTextField = "code";   // Alias name from sproc
            DropDownList1.DataBind();

            SQLDBConn.Close();
        }
    }
    protected void post(object sender, EventArgs e)
    {

        int ssn = Convert.ToInt32(Session["student"]);
        String coursecode = DropDownList1.SelectedValue;
        String question = TextBox1.Text;
        if (question != "")
        {
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlCommand cmd = new SqlCommand("Ask", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@course_code", coursecode));
            cmd.Parameters.Add(new SqlParameter("@ssn", ssn));
            cmd.Parameters.Add(new SqlParameter("@question", question));
            cmd.ExecuteNonQuery();
            conn.Close();
            Label4.Text = "Done";
        }
        else
        {
            Label4.Text = "please type in your question";
        }
    }
}