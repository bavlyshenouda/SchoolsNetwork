﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LoadInventoryCategoryDropDownList();
    }

    private void LoadInventoryCategoryDropDownList()
    {
        if (!Page.IsPostBack)
        {
            int ssn = Convert.ToInt32(Session["student"]);
            SqlCommand SQLSelectCommand;
            SqlDataReader dtrInventoryCategory;

            string SQLDBConnString = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection SQLDBConn = new SqlConnection(SQLDBConnString);

            SQLDBConn.Open();

            SQLSelectCommand = new SqlCommand("ViewCourses", SQLDBConn);
            SQLSelectCommand.CommandType = CommandType.StoredProcedure;
            SQLSelectCommand.Parameters.Add(new SqlParameter("@ssn", ssn));

            dtrInventoryCategory = SQLSelectCommand.ExecuteReader();

            DropDownList1.DataSource = dtrInventoryCategory;

            DropDownList1.DataValueField = "code"; // Alias Name from Sproc
            DropDownList1.DataTextField = "code";   // Alias name from sproc
            DropDownList1.DataBind();

            SQLDBConn.Close();
        }
    }
    protected void Show(object sender, EventArgs e)
    {
            int ssn = Convert.ToInt32(Session["student"]);
            String course = DropDownList1.SelectedValue;
            SqlCommand SQLSelectCommand;
            SqlDataReader dtrInventoryCategory;

            string SQLDBConnString = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection SQLDBConn = new SqlConnection(SQLDBConnString);

            SQLDBConn.Open();

            SQLSelectCommand = new SqlCommand("ViewAssignmentsCourse", SQLDBConn);
            SQLSelectCommand.CommandType = CommandType.StoredProcedure;
            SQLSelectCommand.Parameters.Add(new SqlParameter("@ssn", ssn));
            SQLSelectCommand.Parameters.Add(new SqlParameter("@course_code", course));

            dtrInventoryCategory = SQLSelectCommand.ExecuteReader();

            DropDownList2.DataSource = dtrInventoryCategory;

            DropDownList2.DataValueField = "number"; // Alias Name from Sproc
            DropDownList2.DataTextField = "number";   // Alias name from sproc
            DropDownList2.DataBind();

            SQLDBConn.Close();
        }
    
    protected void fill_grid(object sender, EventArgs e)
    {

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        String course = DropDownList1.SelectedValue;
        int number = Convert.ToInt32(DropDownList2.SelectedValue);
        conn.Open();
        SqlCommand cmd = new SqlCommand("GetAssignemnt", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@number", number));
        cmd.Parameters.Add(new SqlParameter("@course_code", course));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();

    }
    protected void post(object sender, EventArgs e)
    {
        int ssn = Convert.ToInt32(Session["student"]);
        String course = DropDownList1.SelectedValue;
        int number= Convert.ToInt32(DropDownList2.SelectedValue);
        String answer = TextBox1.Text;
        //Get the information of the connection to the database
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("SolveAssignments", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        if (answer != null)
        {
            cmd.Parameters.Add(new SqlParameter("@ssn", ssn));
            cmd.Parameters.Add(new SqlParameter("@course_code", course));
            cmd.Parameters.Add(new SqlParameter("@assignments_number", number));
            cmd.Parameters.Add(new SqlParameter("@answer", answer));
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            Label4.Text = "Done";
        }
        else
            Label4.Text = "Please fill in the answers";

    }
    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("StudentMain.aspx", true);
    }

}