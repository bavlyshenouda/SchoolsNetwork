﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LoadInventoryCategoryDropDownList();
    }
    private void LoadInventoryCategoryDropDownList()
    {

        if (!Page.IsPostBack)
        {
            int ssn = Convert.ToInt32(Session["student"]);
            SqlCommand SQLSelectCommand;
            SqlDataReader dtrInventoryCategory;

            string SQLDBConnString = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
            SqlConnection SQLDBConn = new SqlConnection(SQLDBConnString);

            SQLDBConn.Open();

            SQLSelectCommand = new SqlCommand("ViewCourses", SQLDBConn);
            SQLSelectCommand.CommandType = CommandType.StoredProcedure;
            SQLSelectCommand.Parameters.Add(new SqlParameter("@ssn", ssn));

            dtrInventoryCategory = SQLSelectCommand.ExecuteReader();

            DropDownList1.DataSource = dtrInventoryCategory;

            DropDownList1.DataValueField = "code"; // Alias Name from Sproc
            DropDownList1.DataTextField = "code";   // Alias name from sproc
            DropDownList1.DataBind();

            SQLDBConn.Close();
        }
    }
    protected void fill_grid(object sender, EventArgs e)
    {
       String course = DropDownList1.SelectedValue;
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("ViewQuestions", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@course_code",course));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();

    }
    protected void Home(object sender, EventArgs e)
    {
        Response.Redirect("StudentMain.aspx", true);
    }
}