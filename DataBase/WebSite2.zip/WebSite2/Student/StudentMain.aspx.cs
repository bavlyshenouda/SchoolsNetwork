﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fill_grid();
    }
    protected void fill_grid()
    {
        int ssn = Convert.ToInt32(Session["student"]);

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("GetInfo", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@ssn", ssn));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("UpdateInfo.aspx", true);
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewCourses.aspx", true);
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("PostQuestion.aspx", true);
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewQuestions", true);
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewAssignments", true);
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("SolveAssignments", true);
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Redirect("AssignmentsGrades", true);
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewAnnouncements", true);
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewActivities", true);
    }
    protected void Button10_Click(object sender, EventArgs e)
    {
        Response.Redirect("JoinClub", true);
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        Response.Redirect("CourseSearch", true);
    }
}