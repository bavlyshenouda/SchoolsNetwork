﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_unverified_teachers : System.Web.UI.Page
{
    
    
    protected void Page_Load(object sender, EventArgs e)
    {
        fill_grid();
    }

    protected void fill_grid()
    {
        int id =(int)(Session["field1"]);
       
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("view_teachers", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@admin_id",id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();
    
}
  /*  protected int check_t()
    {
        int check = 0;
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader reader;

        cmd.CommandText = "SELECT * FROM Customers";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = conn;

        conn.Open();

        reader = cmd.ExecuteReader();
        check = reader.GetInt16(Int16);

        conn.Close();
    }*/

    protected int verify()
    {
        int id = (int)(Session["field1"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("verify_teacher", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        int teacher_id = Convert.ToInt32(TextBox1.Text);
        string user = TextBox2.Text;
        string password =TextBox3.Text;
        cmd.Parameters.Add(new SqlParameter("@admin_id", id));
        cmd.Parameters.Add(new SqlParameter("@teacher_id", teacher_id));
        cmd.Parameters.Add(new SqlParameter("@username", user));
        cmd.Parameters.Add(new SqlParameter("@password", password));
        SqlParameter o = cmd.Parameters.Add("@out", SqlDbType.Int);
        o.Direction = ParameterDirection.Output;


        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        return Convert.ToInt32(o.Value.ToString());
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if ((!string.IsNullOrWhiteSpace(TextBox1.Text)) && (!string.IsNullOrWhiteSpace(TextBox2.Text)) && (!string.IsNullOrWhiteSpace(TextBox3.Text)))
        {
            if (verify() != 0) 
            { 
            fill_grid();
            veri.Text = "Verified";
            TextBox1.Text= "";
            TextBox2.Text= "";
            TextBox3.Text= "";
            }
            else
            {
                veri.Text = "The Username you entered is already used";
            }

        }
        else
        {
            veri.Text = "Please Fill all the Blanks";
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox1.Text = GridView1.SelectedRow.Cells[1].Text;
    }
}