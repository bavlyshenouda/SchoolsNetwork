﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_edit_school : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fill_grid();
    }

    protected void fill_grid()
    {
        int id = (int)(Session["field1"]);

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("show_school", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@admin_id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();

    }

    protected int update_school()
    {
        int id = (int)(Session["field1"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("edit_school", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@admin_id", id));
        cmd.Parameters.Add(new SqlParameter("@name", TextBox1.Text));
        cmd.Parameters.Add(new SqlParameter("@school_address", TextBox2.Text));
        cmd.Parameters.Add(new SqlParameter("@school_type", DropDownList1.SelectedValue));
        cmd.Parameters.Add(new SqlParameter("@mission", TextBox4.Text));
        cmd.Parameters.Add(new SqlParameter("@vision", TextBox5.Text));
        cmd.Parameters.Add(new SqlParameter("@general_info", TextBox6.Text));
        cmd.Parameters.Add(new SqlParameter("@phone_number", TextBox7.Text));
        cmd.Parameters.Add(new SqlParameter("@email", TextBox8.Text));
        cmd.Parameters.Add(new SqlParameter("@main_language", TextBox9.Text));
        cmd.Parameters.Add(new SqlParameter("@fees", Convert.ToDecimal(TextBox10.Text)));


        SqlParameter o = cmd.Parameters.Add("@out", SqlDbType.Int);
        o.Direction = ParameterDirection.Output;


        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        return Convert.ToInt32(o.Value.ToString());

    }



    protected void Button1_Click(object sender, EventArgs e)
    {
        if ((!string.IsNullOrWhiteSpace(TextBox1.Text)) && (!string.IsNullOrWhiteSpace(TextBox2.Text)) && (!string.IsNullOrWhiteSpace(TextBox4.Text)) && (!string.IsNullOrWhiteSpace(TextBox9.Text))
            && (!string.IsNullOrWhiteSpace(TextBox5.Text)) && (!string.IsNullOrWhiteSpace(TextBox6.Text)) && (!string.IsNullOrWhiteSpace(TextBox7.Text)) && (!string.IsNullOrWhiteSpace(TextBox8.Text)) && (!string.IsNullOrWhiteSpace(TextBox10.Text)))
        {
            if (update_school() != 0)
            {
                veri.Text = "School information has been updated successfully";
                fill_grid();
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox4.Text = "";
                TextBox5.Text = "";
                TextBox6.Text = "";
                TextBox7.Text = "";
                TextBox8.Text = "";
                TextBox9.Text = "";
                TextBox10.Text = "";
            }
            else
            {
                veri.Text = "This email is already used!";
            }
           
        }
        else
        {
            veri.Text = "Please fill all the blanks!";
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox1.Text = GridView1.SelectedRow.Cells[2].Text;
        TextBox2.Text = GridView1.SelectedRow.Cells[6].Text;
        TextBox4.Text = GridView1.SelectedRow.Cells[3].Text;
        TextBox5.Text = GridView1.SelectedRow.Cells[4].Text;
        TextBox6.Text = GridView1.SelectedRow.Cells[7].Text;
        TextBox7.Text = GridView1.SelectedRow.Cells[8].Text;
        TextBox8.Text = GridView1.SelectedRow.Cells[11].Text;
        TextBox9.Text = GridView1.SelectedRow.Cells[9].Text;
        TextBox10.Text = GridView1.SelectedRow.Cells[5].Text;
    }
}