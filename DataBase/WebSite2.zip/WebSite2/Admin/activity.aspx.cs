﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_activity : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fill_grid();
        fill_grid2();
    }
    protected void create_activity()
    {
        int id = (int)(Session["field1"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("create_activity", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        DateTime date = DateTime.ParseExact("2000-01-23", "yyyy-mm-dd", null);
        try
        {
            date = DateTime.ParseExact(TextBox3.Text, "yyyy-mm-dd", null);
        }
        catch (Exception)
        {
            veri.Text = "Please enter the date in the correct format YYYY-MM-DD";
            return;
        }
        cmd.Parameters.Add(new SqlParameter("@administrator_id", id));
        cmd.Parameters.Add(new SqlParameter("@activity_description",TextBox1.Text));
        cmd.Parameters.Add(new SqlParameter("@activity_type",TextBox2.Text));
        cmd.Parameters.Add(new SqlParameter("@date_released",date));
        cmd.Parameters.Add(new SqlParameter("@activity_location", TextBox4.Text));
        cmd.Parameters.Add(new SqlParameter("@equipment", TextBox5.Text));


        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }
    protected void assign_teacher()
    {
        int id = (int)(Session["field1"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("assign_activity_teacher", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        int ac_id = Convert.ToInt32(TextBox7.Text);
        int te_id = Convert.ToInt32(TextBox6.Text);
        cmd.Parameters.Add(new SqlParameter("@admin_id", id));
        cmd.Parameters.Add(new SqlParameter("@activity_id",ac_id));
        cmd.Parameters.Add(new SqlParameter("@teacher_id",te_id));
        


        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }
    protected void fill_grid()
    {
        int id = (int)(Session["field1"]);

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("view_unassigned_activities", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@admin_id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();

    }

    protected void fill_grid2()
    {
        int id = (int)(Session["field1"]);

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("unassigned_teachers_activities", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@admin_id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView2.DataSource = d;
        GridView2.DataBind();
        conn.Close();

    }

    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox6.Text = GridView2.SelectedRow.Cells[1].Text;
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox7.Text = GridView1.SelectedRow.Cells[1].Text;
    }



    protected void Button1_Click(object sender, EventArgs e)
    {
        if ((!string.IsNullOrWhiteSpace(TextBox1.Text)) && (!string.IsNullOrWhiteSpace(TextBox2.Text)) && (!string.IsNullOrWhiteSpace(TextBox3.Text)) && (!string.IsNullOrWhiteSpace(TextBox4.Text)))
        {
            create_activity();
            veri.Text = "Activity has been created successfully";
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            fill_grid();
        }
        else
        {
            veri.Text = "Pleaes fill in the required blanks";
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        if ((!string.IsNullOrWhiteSpace(TextBox6.Text)) && (!string.IsNullOrWhiteSpace(TextBox7.Text)))
        {
            assign_teacher();
            assign.Text = "Teacher was Successfully assigned to an acctivity";
            TextBox6.Text = "";
            TextBox7.Text = "";
            fill_grid();
            fill_grid2();
        }
        else
        {
            assign.Text = "Please select a Teacher and an Activity";
        }
    }
}