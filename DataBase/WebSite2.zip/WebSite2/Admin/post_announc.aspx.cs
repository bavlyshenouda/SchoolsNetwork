﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_post_announc : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fill_grid();
    }

    protected void fill_grid()
    {
        int id = (int)(Session["field1"]);

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("view_announcements", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@admin_id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();

    }

    protected void post()
    {
        int id = (int)(Session["field1"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("post_announcement", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@administrator_id", id));
        cmd.Parameters.Add(new SqlParameter("@announcement_description",TextBox1.Text));
        cmd.Parameters.Add(new SqlParameter("@announcement_type",TextBox2.Text));
        cmd.Parameters.Add(new SqlParameter("@title",TextBox3.Text));


        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if ((!string.IsNullOrWhiteSpace(TextBox1.Text)) && (!string.IsNullOrWhiteSpace(TextBox2.Text)) && (!string.IsNullOrWhiteSpace(TextBox3.Text)))
        {
            post();
            fill_grid();
            veri.Text = "Announcement has been posted successfully!";
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";

        }
        else
        {
            veri.Text = "Please Fill all the Blanks";
        }
    }
}