﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_list_requests : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fill_grid();
    }

    protected void fill_grid()
    {
        int id = (int)(Session["field1"]);

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("view_applicants", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@admin_id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();

    }

    protected void verify()
    {
        int id = (int)(Session["field1"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("accept_reject_app", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        int student_ssn = Convert.ToInt32(TextBox1.Text);
        cmd.Parameters.Add(new SqlParameter("@child_ssn",student_ssn));
        cmd.Parameters.Add(new SqlParameter("@admin_id",id));
        cmd.Parameters.Add(new SqlParameter("@accept",DropDownList1.SelectedIndex));
        


        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(TextBox1.Text))
        {
            verify();
            fill_grid();
            veri.Text = "Verified";
            TextBox1.Text = "";
        }
        else
        {
            veri.Text = "Please Fill all the Blanks";
        }
    }

  
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        TextBox1.Text = GridView1.SelectedRow.Cells[1].Text;
    }
}