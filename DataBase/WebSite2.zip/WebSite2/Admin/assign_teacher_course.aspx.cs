﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_assign_teacher_course : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fill_grid();
        fill_grid2();
    }

    public void assign_teacher_course()
    {
        int id = (int)(Session["field1"]);
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand("assgin_course_teacher", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        int te_id = Convert.ToInt32(TextBox7.Text);
        cmd.Parameters.Add(new SqlParameter("@admin_id",id));
        cmd.Parameters.Add(new SqlParameter("@course_code",TextBox6.Text));
        cmd.Parameters.Add(new SqlParameter("@teacher_id",te_id));
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }

    protected void fill_grid()
    {
        int id = (int)(Session["field1"]);

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("course_school_offer", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@admin_id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView1.DataSource = d;
        GridView1.DataBind();
        conn.Close();

    }

    protected void fill_grid2()
    {
        int id = (int)(Session["field1"]);

        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);
        conn.Open();
        SqlCommand cmd = new SqlCommand("teacher_no_course", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@admin_id", id));
        cmd.ExecuteNonQuery();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable d = new DataTable();
        da.Fill(d);
        GridView2.DataSource = d;
        GridView2.DataBind();
        conn.Close();

    }

    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox7.Text = GridView2.SelectedRow.Cells[1].Text;
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox6.Text = GridView1.SelectedRow.Cells[1].Text;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        if ((!string.IsNullOrWhiteSpace(TextBox6.Text)) && (!string.IsNullOrWhiteSpace(TextBox7.Text)))
        {
            assign_teacher_course();
            fill_grid();
            fill_grid2();
            assign.Text = "Teacher has been assigned to a course successfully";
        }
        else
        {
            assign.Text = "Please select a course and a teacher";
        }
    }
}