﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
public partial class pages_login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        
        //Get the information of the connection to the database
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("log_in", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string usernamee = username.Text;
        string passs=password.Text;
        


        cmd.Parameters.Add(new SqlParameter("@username",usernamee));
        cmd.Parameters.Add(new SqlParameter("@password",passs));
        


        SqlParameter count = cmd.Parameters.Add("@o", SqlDbType.Int);
        count.Direction = ParameterDirection.Output;

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        if (count.Value.ToString().Equals("1"))
        {
            Session["parentusername"] = usernamee;
         Response.Redirect("Parent.aspx", true);
       

        }
        else
        {
           
        }
    }


    protected void username_TextChanged(object sender, EventArgs e)
    {

    }
    protected void password_TextChanged(object sender, EventArgs e)
    {

    }
}


