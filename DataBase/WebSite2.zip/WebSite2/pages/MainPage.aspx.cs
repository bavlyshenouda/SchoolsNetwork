﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class pages_MainPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Admin_login()
    {
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("Admin_Login", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string user = username.Text;
        string password = pass.Text;

        cmd.Parameters.Add(new SqlParameter("@username", user));
        cmd.Parameters.Add(new SqlParameter("@password", password));
        SqlParameter o = cmd.Parameters.Add("@out", SqlDbType.Int);
        o.Direction = ParameterDirection.Output;
        int id = Convert.ToInt32(o.Value.ToString());
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        if (id != 0)
        {

            Session[0] = id;
            Response.Redirect("AdminMain.aspx", true);
        }
        else
        {
            warning.Text = "You entered a wrong username or password";
        }


    }

    protected void Button1_Click(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        if ((!string.IsNullOrWhiteSpace(username.Text)) && (!string.IsNullOrWhiteSpace(pass.Text)))
        {
            if (DropDownList1.SelectedItem.Equals("Admin"))
            {
                Admin_login();
            }
        }
    }
}