﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


public partial class pages_myreviews : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Get the information of the connection to the database
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/

        SqlCommand cmd = new SqlCommand("showmyreviewss", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string userr = (String)Session["parentusername"];
        cmd.Parameters.Add(new SqlParameter("@parent_username", userr));
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        GridView1.DataSource = dt.DefaultView;
        GridView1.DataBind();
        
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        int a = GridView1.SelectedIndex;
        string sid="";
        foreach (GridViewRow row in GridView1.Rows)
        {
            if (row.RowIndex == a)
            {
                sid = row.Cells[2].Text;
                
            }
        }
        //Get the information of the connection to the database
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        int sidd = Convert.ToInt32(sid);
        SqlCommand cmd = new SqlCommand("delete_review", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string userr = (String)Session["parentusername"];
        cmd.Parameters.Add(new SqlParameter("@parent_username", userr));
        cmd.Parameters.Add(new SqlParameter("@school_idd",sidd));
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        
     

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Parent.aspx", true);
    }
}