﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class pages_ChildrensReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Get the information of the connection to the database
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("show_report", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        String userr = (String)Session["parentusername"];
        cmd.Parameters.Add(new SqlParameter("@parent_username",userr));
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();

        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        GridView2.DataSource = dt.DefaultView;
        GridView2.DataBind();

    }

    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

        int a = GridView2.SelectedIndex;

        foreach (GridViewRow row in GridView2.Rows)
        {
            if (row.RowIndex == a)
            {
                Session["ssnchildr"] = row.Cells[2].Text;
                Session["tidod"] = row.Cells[6].Text;
                Session["dater"] = row.Cells[0].Text;
            }
        }
        
        Response.Redirect("YourReply.aspx", true);
        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Parent.aspx", true);
    }
}