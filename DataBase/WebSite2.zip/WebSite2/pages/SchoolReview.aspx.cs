﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class pages_SchoolReview : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         
            //Get the information of the connection to the database
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("write_review", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string reviewi=review1.Text;
        string ids= (String)Session["schoolreviewid"];
        string user = (String)Session["parentusername"];
        cmd.Parameters.Add(new SqlParameter("@review", reviewi));
        cmd.Parameters.Add(new SqlParameter("@parent_username", user));
        cmd.Parameters.Add(new SqlParameter("@school_id", ids));
        
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        Response.Redirect("Parent.aspx", true);
    }
    protected void review1_TextChanged(object sender, EventArgs e)
    {

    }
}