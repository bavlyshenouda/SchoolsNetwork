﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class pages_AcceptedSchools : System.Web.UI.Page
{
   protected void Page_Load(object sender, EventArgs e){
       //Get the information of the connection to the database
       string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

       //create a new connection
       SqlConnection conn = new SqlConnection(connStr);

       /*create a new SQL command which takes as parameters the name of the stored procedure and
        the SQLconnection name*/
       SqlCommand cmd = new SqlCommand("accepted_schools", conn);
       cmd.CommandType = CommandType.StoredProcedure;
       String userr = (String)Session["parentusername"];

       cmd.Parameters.Add(new SqlParameter("@parent_username", userr));
       conn.Open();
       cmd.ExecuteNonQuery();
       conn.Close();

       SqlDataAdapter sda = new SqlDataAdapter(cmd);
       DataTable dt = new DataTable();
       sda.Fill(dt);
       GridView1.DataSource = dt.DefaultView;
       GridView1.DataBind();
    }
   
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

        int a = GridView1.SelectedIndex;

        foreach (GridViewRow row in GridView1.Rows)
        {
            if (row.RowIndex == a)
            {
                Session["ssnchild"] = row.Cells[1].Text;
                Session["chosenschool"] = row.Cells[3].Text;
            }
        }
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);

        /*create a new SQL command which takes as parameters the name of the stored procedure and
         the SQLconnection name*/
        SqlCommand cmd = new SqlCommand("choose_school", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string user = (String)Session["parentusername"];
        int accepted = Convert.ToInt32((String)Session["chosenschool"]);
        int child = Convert.ToInt32((String)Session["ssnchild"]);

        cmd.Parameters.Add(new SqlParameter("@parent_username", user));
        cmd.Parameters.Add(new SqlParameter("@school_id", accepted));
        cmd.Parameters.Add(new SqlParameter("@child_ssn", child));
        
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Parent.aspx", true);
    }
    
}