﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


public partial class pages_YourReply : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
     
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

        //create a new connection
        SqlConnection conn = new SqlConnection(connStr);
        
        SqlCommand cmd = new SqlCommand("reply_reports",conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string user = (String)Session["parentusername"];
        int child = Convert.ToInt32(((String)Session["ssnchildr"]));
        int tidodod= Convert.ToInt32(((String)Session["tidod"]));
        string temp=(String)Session["dater"];
        string Replyy = reply2.Text;
        

        DateTime dt = DateTime.ParseExact(temp,"dd/MM/yyyy",null);
        cmd.Parameters.Add(new SqlParameter("@parent_username", user));
        cmd.Parameters.Add(new SqlParameter("@teacher_id", tidodod));
        cmd.Parameters.Add(new SqlParameter("@student_ssn", child));
        cmd.Parameters.Add(new SqlParameter("@parent_reply",Replyy));
        cmd.Parameters.Add(new SqlParameter("@date_released",dt.Date));
     
        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();

       
    }
    protected void reply_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Parent.aspx", true);
    }
}