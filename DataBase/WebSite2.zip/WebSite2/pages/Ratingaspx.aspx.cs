﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Threading;

public partial class pages_Ratingaspx : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Text = ((string)Session["avgg"]);
        Label3.Visible = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            int test = Convert.ToInt32(rati.Text);
        }
        catch
              (Exception)
        {
            warning.Text = "Rate must be integer";
            return;
        }
        string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();
        SqlConnection conn = new SqlConnection(connStr);

        SqlCommand cmd = new SqlCommand("rate_teacher", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        string user = (String)Session["parentusername"];

        int tid = Convert.ToInt32((String)Session["tiii"]);

        int rt = Convert.ToInt32(rati.Text);
        cmd.Parameters.Add(new SqlParameter("@parent_username",user));
        cmd.Parameters.Add(new SqlParameter("@teacher_id", tid));
        cmd.Parameters.Add(new SqlParameter("@rate",rt));
         SqlParameter count = cmd.Parameters.Add("@o", SqlDbType.Int);
        count.Direction = ParameterDirection.Output;

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
        if (count.Value.ToString().Equals("1"))
        {
            warning.Text = "You Rated that teacher ";
            cmd = new SqlCommand("avg_trate", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            int tot = Convert.ToInt32((String)Session["tiii"]);


            cmd.Parameters.Add(new SqlParameter("@teacher_idd", tot));
            SqlParameter outt = cmd.Parameters.Add("@result", SqlDbType.Int);
           outt.Direction = ParameterDirection.Output;
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            Session["avgg"] = outt.Value.ToString();


            Response.Redirect("Ratingaspx.aspx", true);
           

            
            }
        else {  warning.Text = "You have already rated that teacher or your rating is out of range ";
       
       
      
        }
        

      
    }
    protected void rati_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("TeachersReview.aspx", true);


    }
}