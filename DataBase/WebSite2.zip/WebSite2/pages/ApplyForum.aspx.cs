﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
public partial class pages_ApplyForum : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            int test = Convert.ToInt32(ssnn.Text);
        }
        catch
            (Exception)
        {
            warning.Text = "SSN must be integer";
            return;
        }
        DateTime DDate;
        try
        {
            DDate = DateTime.ParseExact(date.Text, "dd/MM/yyyy", null);
        }
        catch (Exception)
        {
            warning.Text = "Please enter the date correctly";
            warning.Visible = true;
            return;

        }
        if ((!string.IsNullOrWhiteSpace(namee.Text)) && (!string.IsNullOrWhiteSpace(ssnn.Text)) && (!string.IsNullOrWhiteSpace(date.Text)))
        {
            warning.Text = "";

            //Get the information of the connection to the database
            string connStr = ConfigurationManager.ConnectionStrings["MyDbConn"].ToString();

            //create a new connection
            SqlConnection conn = new SqlConnection(connStr);

            /*create a new SQL command which takes as parameters the name of the stored procedure and
             the SQLconnection name*/
            SqlCommand cmd = new SqlCommand("apply", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            int snn = Convert.ToInt32(ssnn.Text);
            string name = namee.Text;
            DateTime dt = DateTime.ParseExact(date.Text, "dd/MM/yyyy", null);

            char gend = DropDownList1.SelectedValue[0];
            string userr = (String)Session["parentusername"];
            int schoolid = Convert.ToInt32((String)Session["schoolapplyid"]);

            cmd.Parameters.Add(new SqlParameter("@parent_username", userr));
            cmd.Parameters.Add(new SqlParameter("@school_id", schoolid));
            cmd.Parameters.Add(new SqlParameter("@child_ssn", snn));
            cmd.Parameters.Add(new SqlParameter("@child_name", name));
            cmd.Parameters.Add(new SqlParameter("@child_birthdate", dt.Date));
            cmd.Parameters.Add(new SqlParameter("@gender ", gend));


            conn.Open();

            cmd.ExecuteNonQuery();
            conn.Close();
            Response.Redirect("Parent.aspx", true);
        }
        else { warning.Text = "Please Fill the Essential Fields"; }
       
    }
    protected void date_TextChanged(object sender, EventArgs e)
    {

    }
    protected void date_TextChanged1(object sender, EventArgs e)
    {

    }
}